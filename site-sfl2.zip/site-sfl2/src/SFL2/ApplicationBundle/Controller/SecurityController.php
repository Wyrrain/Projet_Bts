<?php

namespace SFL2\ApplicationBundle\Controller;

use SFL2\ApplicationBundle\Entity\Utilisateur;
use Symfony\Bundle\FrameworkBundle\Controller\Controller; 
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class SecurityController extends Controller{
    
    public function loginAction(Request $request){
        
        $login = new Utilisateur();
        
        $form = $this->createForm('SFL2\ApplicationBundle\Form\ConnexionType', $login);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {


            
            
            //return $this->render('SFL2ApplicationBundle:Default:index.html.twig');
            return $this->redirectToRoute('sfl2_homepage');
        }

        return $this->render('SFL2ApplicationBundle:Connexion:connexion.html.twig', array('form' => $form->createView()));
    }
}