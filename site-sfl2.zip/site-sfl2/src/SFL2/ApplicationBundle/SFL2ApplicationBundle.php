<?php

namespace SFL2\ApplicationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SFL2ApplicationBundle extends Bundle
{
}
