<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request;
        $requestMethod = $canonicalMethod = $context->getMethod();
        $scheme = $context->getScheme();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }


        // sfl2_firstpage
        if ('' === $trimmedPathinfo) {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($rawPathinfo.'/', 'sfl2_firstpage');
            }

            return array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\DefaultController::indexAction',  '_route' => 'sfl2_firstpage',);
        }

        // sfl2_homepage
        if ('/accueil' === $pathinfo) {
            return array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\DefaultController::accueilAction',  '_route' => 'sfl2_homepage',);
        }

        if (0 === strpos($pathinfo, '/utilisateurs')) {
            // sfl2_utilisateurs_index
            if ('/utilisateurs' === $pathinfo) {
                return array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\UtilisateurController::indexAction',  '_route' => 'sfl2_utilisateurs_index',);
            }

            // sfl2_utilisateurs_add
            if ('/utilisateurs/add' === $pathinfo) {
                return array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\UtilisateurController::addAction',  '_route' => 'sfl2_utilisateurs_add',);
            }

            // sfl2_utilisateurs_del
            if (preg_match('#^/utilisateurs/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sfl2_utilisateurs_del')), array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\UtilisateurController::deleteAction',));
            }

            // sfl2_utilisateurs_edit
            if (preg_match('#^/utilisateurs/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sfl2_utilisateurs_edit')), array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\UtilisateurController::editAction',));
            }

        }

        elseif (0 === strpos($pathinfo, '/emprunts')) {
            // sfl2_emprunts_index
            if ('/emprunts' === $pathinfo) {
                return array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\EmpruntController::indexAction',  '_route' => 'sfl2_emprunts_index',);
            }

            // sfl2_emprunts_add
            if ('/emprunts/add' === $pathinfo) {
                return array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\EmpruntController::addAction',  '_route' => 'sfl2_emprunts_add',);
            }

            // sfl2_emprunts_del
            if (preg_match('#^/emprunts/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sfl2_emprunts_del')), array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\EmpruntController::deleteAction',));
            }

            // sfl2_emprunts_edit
            if (preg_match('#^/emprunts/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sfl2_emprunts_edit')), array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\EmpruntController::editAction',));
            }

        }

        // sfl2_localisation
        if ('/localisation' === $pathinfo) {
            return array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\LocalisationController::localisationAction',  '_route' => 'sfl2_localisation',);
        }

        // sfl2_login
        if ('/login' === $pathinfo) {
            return array (  '_controller' => 'SFL2\\ApplicationBundle\\Controller\\SecurityController::loginAction',  '_route' => 'sfl2_login',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
