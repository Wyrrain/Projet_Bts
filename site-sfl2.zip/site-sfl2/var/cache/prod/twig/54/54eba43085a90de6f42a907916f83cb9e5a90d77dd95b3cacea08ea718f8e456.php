<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* SFL2ApplicationBundle:Utilisateur:index.html.twig */
class __TwigTemplate_8e49e5f276fc3f6955f7a0fd2af472e89d4652c3687164a3def8f5fe0a6495e4 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 2
        echo twig_include($this->env, $context, "base.html.twig");
        echo "

";
        // line 4
        $this->displayBlock('body', $context, $blocks);
    }

    public function block_body($context, array $blocks = [])
    {
        // line 5
        echo "    <h1 style=\"text-align: center\">Gestion des Utilisateurs</h1>
  
    <a href=\"utilisateurs/add\" class=\"btn btn-secondary btn-md\" role=\"button\" aria-disabled=\"true\">Ajouter un utilisateur</a>
    <p></br></p>
    <table class=\"table table-striped\">
        <thead>
            <tr>

                <th scope=\"col\">Nom</th>
                <th scope=\"col\">Prénom</th>
                <th scope=\"col\">Fonction</th>
                <th scope=\"col\">Identifiant</th>
                <th scope=\"col\">Mot de passe</th>
                <th scope=\"col\">Commentaires</th>
                <th scope=\"col\">Modification</th>
            </tr>
        </thead>
        <tbody>

            ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["utilisateurs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 25
            echo "           
                <tr>

                    <td>";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "nom", []), "html", null, true);
            echo "</td>
                    <td>";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "prenom", []), "html", null, true);
            echo "</td>
                    <td>";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "fonction", []), "html", null, true);
            echo "</td>
                    <td>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "login", []), "html", null, true);
            echo "</td>
                    <td>";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "motdepasse", []), "html", null, true);
            echo "</td>
                    <td>";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "commentaires", []), "html", null, true);
            echo "</td>
  
                    <td><a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("sfl2_utilisateurs_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [])]), "html", null, true);
            echo "\" class=\"btn btn-secondary btn-sm\" role=\"button\" aria-disabled=\"true\">modifier</a>
                        <a href=\"\" class=\"btn btn-secondary btn-sm\" role=\"button\" aria-disabled=\"true\" data-toggle=\"modal\" data-target=\"#delete_";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "id", []), "html", null, true);
            echo "\">supprimer</a>
                       
                    </td>
                </tr>
                <div class=\"modal fade\" id=\"delete_";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "id", []), "html", null, true);
            echo "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"deleteLabel\" aria-hidden=\"true\">
                <div class=\"modal-dialog\" role=\"document\">
                  <div class=\"modal-content\">
                    <div class=\"modal-header\">
                      <h5 class=\"modal-title\" id=\"exampleModalLabel\">Supression</h5>
                      <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                        <span aria-hidden=\"true\">&times;</span>
                      </button>
                    </div>
                    <div class=\"modal-body\">
                      Voulez-vous vraiment supprimer ";
            // line 50
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "NomPrenom", []), "html", null, true);
            echo "?
                    </div>
                    <div class=\"modal-footer\">
                      <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Non</button>
                      <a href=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("sfl2_utilisateurs_del", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [])]), "html", null, true);
            echo "\" class=\"btn btn-secondary\" role=\"button\" aria-disabled=\"true\">Oui</a>
                    </div>
                  </div>
                </div>
              </div>
                
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "        </tbody>
        <tfoot>
            <tr>

                <th scope=\"col\">Nom</th>
                <th scope=\"col\">Prénom</th>
                <th scope=\"col\">Fonction</th>
                <th scope=\"col\">Identifiant</th>
                <th scope=\"col\">Mot de passe</th>
                <th scope=\"col\">Commentaires</th>
                <th scope=\"col\">Modification</th>
            </tr>
        </tfoot>
    </table>
";
    }

    public function getTemplateName()
    {
        return "SFL2ApplicationBundle:Utilisateur:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 61,  133 => 54,  126 => 50,  113 => 40,  106 => 36,  102 => 35,  97 => 33,  93 => 32,  89 => 31,  85 => 30,  81 => 29,  77 => 28,  72 => 25,  68 => 24,  47 => 5,  41 => 4,  36 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "SFL2ApplicationBundle:Utilisateur:index.html.twig", "C:\\wamp64\\www\\site-sfl2\\src\\SFL2\\ApplicationBundle/Resources/views/Utilisateur/index.html.twig");
    }
}
