<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* SFL2ApplicationBundle:Emprunt:index.html.twig */
class __TwigTemplate_277326164b55483d6cdac946539c2bc58f95883b71db212aa1a2fe7e5199b06c extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 2
        echo twig_include($this->env, $context, "base.html.twig");
        echo "

";
        // line 4
        $this->displayBlock('body', $context, $blocks);
    }

    public function block_body($context, array $blocks = [])
    {
        // line 5
        echo "    <div class=\"container-fluid\">
        <h1 style=\"text-align: center\">Gestion des Emprunts</h1>

        <p>
            <a href=\"emprunts/add\" class=\"btn btn-secondary btn-md\" role=\"button\" aria-disabled=\"true\">Ajouter un emprunt</a>
        </p>
        
        <table class=\"table table-striped\">
            <thead>
                <tr>
                    <th scope=\"col1\">id</th>
                    <th scope=\"col\">Article</th>
                    <th scope=\"col\">Marque</th>
                    <th scope=\"col\">Début de l'emprunt</th>
                    <th scope=\"col\">Fin de l'emprunt</th>
                    <th scope=\"col\">Emprunté par :</th>
                    <th scope=\"col\">Modification</th>
                </tr>
            </thead>
            <tbody>


                ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["emprunts"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["emprunt"]) {
            // line 28
            echo "                    <tr>
                        <td>";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["emprunt"], "id", []), "html", null, true);
            echo "</td>
                        <td>";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["emprunt"], "article", []), "nom", []), "html", null, true);
            echo "</td>
                        <td>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["emprunt"], "article", []), "marque", []), "html", null, true);
            echo "</td>
                        <td>";
            // line 32
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["emprunt"], "debut", []), "d-m-Y"), "html", null, true);
            echo "</td>
                        <td>";
            // line 33
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["emprunt"], "fin", []), "d-m-Y"), "html", null, true);
            echo "</td>
                        <td>";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["emprunt"], "utilisateur", []), "nom", []), "html", null, true);
            echo "</td>
                        


                        <td><a href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("sfl2_emprunts_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["emprunt"], "id", [])]), "html", null, true);
            echo "\" class=\"btn btn-secondary btn-sm\" role=\"button\" aria-disabled=\"true\">modifier</a>
                            <a href=\"\" class=\"btn btn-secondary btn-sm\" role=\"button\" aria-disabled=\"true\" data-toggle=\"modal\" data-target=\"#delete_";
            // line 39
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["emprunt"], "id", []), "html", null, true);
            echo "\">supprimer</a>

                        </td>
                    </tr>
                    
                <div class=\"modal fade\" id=\"delete_";
            // line 44
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["emprunt"], "id", []), "html", null, true);
            echo "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"deleteLabel\" aria-hidden=\"true\">
                    <div class=\"modal-dialog\" role=\"document\">
                        <div class=\"modal-content\">
                            <div class=\"modal-header\">
                                <h5 class=\"modal-title\" id=\"exampleModalLabel\">Supression</h5>
                                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                                    <span aria-hidden=\"true\">&times;</span>
                                </button>
                            </div>
                            <div class=\"modal-body\">
                                Voulez-vous vraiment supprimer cet emprunt?
                            </div>
                            <div class=\"modal-footer\">
                                <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Non</button>
                                <a href=\"";
            // line 58
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("sfl2_emprunts_del", ["id" => twig_get_attribute($this->env, $this->source, $context["emprunt"], "id", [])]), "html", null, true);
            echo "\" class=\"btn btn-secondary\" role=\"button\" aria-disabled=\"true\">Oui</a>
                            </div>
                        </div>
                    </div>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['emprunt'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 64
        echo "            </tbody>
            <tfoot>
                <tr>
                    <th scope=\"col1\">id</th>
                    <th scope=\"col\">Article</th>
                    <th scope=\"col\">Marque</th>
                    <th scope=\"col\">Début de l'emprunt</th>
                    <th scope=\"col\">Fin de l'emprunt</th>
                    <th scope=\"col\">Emprunté par :</th>
                    <th scope=\"col\">Modification</th>
                </tr>
            </tfoot>
        </table>
    </div>

    <!-- Modal -->

";
    }

    public function getTemplateName()
    {
        return "SFL2ApplicationBundle:Emprunt:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 64,  134 => 58,  117 => 44,  109 => 39,  105 => 38,  98 => 34,  94 => 33,  90 => 32,  86 => 31,  82 => 30,  78 => 29,  75 => 28,  71 => 27,  47 => 5,  41 => 4,  36 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "SFL2ApplicationBundle:Emprunt:index.html.twig", "C:\\wamp64\\www\\site-sfl2\\src\\SFL2\\ApplicationBundle/Resources/views/Emprunt/index.html.twig");
    }
}
