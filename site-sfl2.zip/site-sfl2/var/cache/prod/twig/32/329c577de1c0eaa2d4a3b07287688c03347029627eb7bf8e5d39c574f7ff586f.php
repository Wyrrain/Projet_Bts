<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* SFL2ApplicationBundle:Utilisateur:add.html.twig */
class __TwigTemplate_c05426298a8e7c6706f582a67407eefa0a9a6018e1e02b62941aff3eb26a3b8d extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo twig_include($this->env, $context, "base.html.twig");
        echo "
";
        // line 2
        $this->displayBlock('body', $context, $blocks);
    }

    public function block_body($context, array $blocks = [])
    {
        // line 3
        echo "    

    <h1 style=\"text-align: center\">Ajout d'un utilisateur</h1>

    <div clas=\"well\">
        ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? null), 'form_start', ["attr" => ["class" => "form-horizontal"]]);
        echo "

        ";
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        echo "



      
        <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fa fa-user\"></i>
                    </div>
                </div>
                ";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "nom", []), 'errors');
        echo "
            
                ";
        // line 25
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "nom", []), 'widget', ["attr" => ["class" => "form-control "]]);
        echo "
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Nom de l'utilisateur</span>
        </div>
        
        <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fa fa-user-o\"></i>
                    </div>
                </div>
                ";
        // line 38
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "prenom", []), 'errors');
        echo "
            
                ";
        // line 40
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "prenom", []), 'widget', ["attr" => ["class" => "form-control "]]);
        echo "
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Prénom de l'utilisateur</span>
        </div>
            
        <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fa fa-briefcase\"></i>
                    </div>
                </div>
                ";
        // line 53
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "fonction", []), 'errors');
        echo "
            
                ";
        // line 55
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "fonction", []), 'widget', ["attr" => ["class" => "form-control "]]);
        echo "
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Fonction de l'utilisateur</span>
        </div>
         
        <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fa fa-phone\"></i>
                    </div>
                </div>
                ";
        // line 68
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "login", []), 'errors');
        echo "
            
                ";
        // line 70
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "login", []), 'widget', ["attr" => ["class" => "form-control "]]);
        echo "
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Identifiant de l'utilisateur</span>
        </div>                    
        
        <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fa fa-envelope\"></i>
                    </div>
                </div>
                ";
        // line 83
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "motdepasse", []), 'errors');
        echo "
            
                ";
        // line 85
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "motdepasse", []), 'widget', ["attr" => ["class" => "form-control "]]);
        echo "
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Mot de passe de l'utilisateur</span>
        </div>
            
        <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fa fa-envelope\"></i>
                    </div>
                </div>
                ";
        // line 98
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "commentaires", []), 'errors');
        echo "
            
                ";
        // line 100
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "commentaires", []), 'widget', ["attr" => ["class" => "form-control "]]);
        echo "
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Commentaires sur l'utilisateur</span>
        </div>
            
            
        <div class=\"form-group\">
            ";
        // line 107
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "ajouter", []), 'widget', ["attr" => ["class" => "btn btn-secondary"]]);
        echo "
        </div>
            
        

        ";
        // line 112
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        echo "

        ";
        // line 114
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        echo "
    </div>

";
    }

    public function getTemplateName()
    {
        return "SFL2ApplicationBundle:Utilisateur:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  207 => 114,  202 => 112,  194 => 107,  184 => 100,  179 => 98,  163 => 85,  158 => 83,  142 => 70,  137 => 68,  121 => 55,  116 => 53,  100 => 40,  95 => 38,  79 => 25,  74 => 23,  58 => 10,  53 => 8,  46 => 3,  40 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "SFL2ApplicationBundle:Utilisateur:add.html.twig", "C:\\wamp64\\www\\site-sfl2\\src\\SFL2\\ApplicationBundle/Resources/views/Utilisateur/add.html.twig");
    }
}
