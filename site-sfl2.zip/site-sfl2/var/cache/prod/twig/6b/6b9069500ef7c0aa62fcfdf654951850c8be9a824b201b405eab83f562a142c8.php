<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* SFL2ApplicationBundle:Default:index.html.twig */
class __TwigTemplate_df230dbf7001259f9968ad6aab059972ce753cc269aaccd7dbd08956a97c7464 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 2
        echo twig_include($this->env, $context, "base.html.twig");
        echo "
<!DOCTYPE html>
<html>
\t
    <head>
        <meta charset=\"UTF-8\">
        <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 9
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 12
        echo "        
    </head>
    <body>
        ";
        // line 15
        $this->displayBlock('body', $context, $blocks);
        // line 63
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 68
        echo "    \t
    </body>
    
</html>
";
    }

    // line 8
    public function block_title($context, array $blocks = [])
    {
        echo "Accueil";
    }

    // line 9
    public function block_stylesheets($context, array $blocks = [])
    {
        // line 10
        echo "            <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">
        ";
    }

    // line 15
    public function block_body($context, array $blocks = [])
    {
        // line 16
        echo "            <div class=\"container-fluid\">
                <h1 style=\"text-align: center;\">Administration des emprunts</h1>
            </div>
            <div class=\"row \">
                <div class=\"col-4 jumbotron\">
                <h1 class=\"display-4\">Utilisateurs</h1>
                              
                <hr class=\"my-4\">
                        <ul class=\"list-group list-group-flush\">
                   
                    </ul>
                <p>Aller à la page gestion des utilisateurs: </p>
                <p class=\"lead\">
                    <a class=\"btn btn-primary btn-lg\" href=\"utilisateurs\" role=\"button\">Gestion des utilisateurs</a>
                </p>
                 ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["utilisateurs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 32
            echo "                
                        <li class=\"list-group-item\">";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "getNomPrenom", [], "method"), "html", null, true);
            echo "</li>
                        
                 ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "                </div>
                
                <div class=\"col-4 jumbotron\">
                <h1 class=\"display-4\">Emprunts</h1>
                <hr class=\"my-4\">
                <p>Aller à la page gestion des emprunts: </p>
                <p class=\"lead\">
                    <a class=\"btn btn-primary btn-lg\" href=\"utilisateurs\" role=\"button\">Gestion des emprunts</a>
                </p>
                ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["emprunt"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["emp"]) {
            // line 46
            echo "                
                        <li class=\"list-group-item\">";
            // line 47
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["emp"], "utilisateur", []), "getNomPrenom", [], "method"), "html", null, true);
            echo " <i class=\"fas fa-arrow-right\"></i>  ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["emp"], "article", []), "getNomMarque", [], "method"), "html", null, true);
            echo "</li>
                        
                 ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['emp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "                </div>
                
                <div class=\"col-4 jumbotron\">
                <h1 class=\"display-4\">Localisation</h1>
                <hr class=\"my-4\">
                <p>Aller à la page de localisation: </p>
                <p class=\"lead\">
                    <a class=\"btn btn-primary btn-lg\" href=\"utilisateurs\" role=\"button\">Localisation</a>
                </p>
                </div>
            </div>
            
        ";
    }

    // line 63
    public function block_javascripts($context, array $blocks = [])
    {
        // line 64
        echo "            <script src=\"https://code.jquery.com/jquery-3.3.1.slim.min.js\" integrity=\"sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo\" crossorigin=\"anonymous\"></script>
\t\t<script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js\" integrity=\"sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1\" crossorigin=\"anonymous\"></script>
\t\t<script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js\" integrity=\"sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM\" crossorigin=\"anonymous\"></script>
        ";
    }

    public function getTemplateName()
    {
        return "SFL2ApplicationBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  170 => 64,  167 => 63,  151 => 50,  140 => 47,  137 => 46,  133 => 45,  122 => 36,  113 => 33,  110 => 32,  106 => 31,  89 => 16,  86 => 15,  81 => 10,  78 => 9,  72 => 8,  64 => 68,  61 => 63,  59 => 15,  54 => 12,  52 => 9,  48 => 8,  39 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "SFL2ApplicationBundle:Default:index.html.twig", "C:\\wamp64\\www\\site-sfl2\\src\\SFL2\\ApplicationBundle/Resources/views/Default/index.html.twig");
    }
}
