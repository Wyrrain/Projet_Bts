<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_8bb1562312ac4de1300b9e9bd68b9899a819106b06e4dbff90389979fa2dc2b9 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 9
        echo "        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"Responsive sidebar template with sliding effect and dropdown menu based on bootstrap 3\">
    
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\"
        crossorigin=\"anonymous\">
    <link href=\"https://use.fontawesome.com/releases/v5.0.6/css/all.css\" rel=\"stylesheet\">
    </head>
    <body>
       
        <div class=\"page-wrapper chiller-theme close-sidebar2\">
  <a id=\"show-sidebar\" class=\"btn btn-sm btn-dark\" href=\"#\">
    <i class=\"fas fa-bars\"></i>
  </a>
  <nav id=\"sidebar\" class=\"sidebar-wrapper\">
    <div class=\"sidebar-content\">
      <div class=\"sidebar-brand\">
        
        <a href=\"/site-sfl2/web/app_dev.php/accueil\"><i class=\"fas fa-home\"></i> Tracabilité RFID</a>
        <div id=\"close-sidebar\">
          <i class=\"fas fa-times\"></i>
        </div>
      </div>
      
      <div class=\"sidebar-menu\">
        <ul>
          <li class=\"header-menu\">
            <span>General</span>
          </li>
          <li class=\"sidebar-dropdown\">
            <a>
              <i class=\"fa fa-user\"></i>
              <span>Gestion des utilisateurs</span>
              
            </a>
            <div class=\"sidebar-submenu\">
              <ul>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/utilisateurs\">Utilisateurs
                    
                  </a>
                </li>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/utilisateurs/add\">Ajouter un utilisateur</a>
                </li>
              </ul>
            </div>
          </li>
          <li class=\"sidebar-dropdown\">
            <a>
              <i class=\"fa fa-suitcase\"></i>
              <span>Gestion des emprunts</span>
             
            </a>
            <div class=\"sidebar-submenu\">
              <ul>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/emprunts\">Emprunts

                  </a>
                </li>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/emprunts/add\">Ajouter un emprunt</a>
                </li>
              
              </ul>
            </div>
          </li>
        
          <li class=\"sidebar-dropdown\">
             <a href=\"/site-sfl2/web/app_dev.php/localisation\">
              <i class=\"fa fa-globe\"></i>
              <span>Localisation</span>
            </a>
            
          </li>
         
      </div>
   
    </div>
    
    <div class=\"sidebar-footer\">
      <a href=\"/site-sfl2/web/app_dev.php/login\">
        Déconnexion <i class=\"fas fa-sign-out-alt\"></i>
      </a>
    </div>
  </nav>
 
  
        ";
        // line 98
        $this->displayBlock('body', $context, $blocks);
        // line 99
        echo "        
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\" integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\"
        crossorigin=\"anonymous\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\"
        crossorigin=\"anonymous\"></script>
    <script src=\"";
        // line 105
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/base.js"), "html", null, true);
        echo "\"></script>
        ";
        // line 106
        $this->displayBlock('javascripts', $context, $blocks);
        // line 107
        echo "    </body>
 
    
    
</html>
";
    }

    // line 5
    public function block_title($context, array $blocks = [])
    {
        echo "Welcome!";
    }

    // line 6
    public function block_stylesheets($context, array $blocks = [])
    {
        // line 7
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/base.css"), "html", null, true);
        echo "\"
        ";
    }

    // line 98
    public function block_body($context, array $blocks = [])
    {
    }

    // line 106
    public function block_javascripts($context, array $blocks = [])
    {
    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  188 => 106,  183 => 98,  176 => 7,  173 => 6,  167 => 5,  158 => 107,  156 => 106,  152 => 105,  144 => 99,  142 => 98,  51 => 9,  49 => 6,  45 => 5,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "base.html.twig", "C:\\wamp64\\www\\site-sfl2\\app\\Resources\\views\\base.html.twig");
    }
}
