<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* SFL2ApplicationBundle:Localisation:localisation.html.twig */
class __TwigTemplate_d0fd64564c1a86c1ccfd39df8803b0154dd45608a5a5a0215dbc5d09124f6b49 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "SFL2ApplicationBundle:Localisation:localisation.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "SFL2ApplicationBundle:Localisation:localisation.html.twig"));

        // line 2
        echo twig_include($this->env, $context, "base.html.twig");
        echo "

<!DOCTYPE html >
    <head>
    <link rel=\"stylesheet\" href=\"https://cdn.rawgit.com/openlayers/openlayers.github.io/master/en/v5.3.0/css/ol.css\" type=\"text/css\">
    <style>
      .map {
        height: 880px;
        width: 100%;
      }
    </style>
    <script src=\"https://cdn.rawgit.com/openlayers/openlayers.github.io/master/en/v5.3.0/build/ol.js\"></script>
    <title>OpenLayers example</title>
  </head>
  <body>
    <h2 style=\"text-align:center\">Localisation</h2>
    <div id=\"map\" class=\"map\"></div>
    <script type=\"text/javascript\">
      var map = new ol.Map({
        target: 'map',
        layers: [
          new ol.layer.Tile({
            source: new ol.source.OSM()
          })
        ],
        view: new ol.View({
          center: ol.proj.fromLonLat([-1.560117, 47.232283]),
          zoom: 19
        })
      });
    </script>
  </body>
47.232283, -1.560117


 <!--script>
      var map;
      function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 47.232283, lng: -1.560117},
          zoom: 19
        });
      }
    </script>
    <script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyB86pOzIw9R_NRKdqfOnjvc0-dVvCuQtn4&callback=initMap\"
    async defer></script-->
  </body>
</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "SFL2ApplicationBundle:Localisation:localisation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# templates/Localisation/localisation.html.twig #}
{{include(\"base.html.twig\")}}

<!DOCTYPE html >
    <head>
    <link rel=\"stylesheet\" href=\"https://cdn.rawgit.com/openlayers/openlayers.github.io/master/en/v5.3.0/css/ol.css\" type=\"text/css\">
    <style>
      .map {
        height: 880px;
        width: 100%;
      }
    </style>
    <script src=\"https://cdn.rawgit.com/openlayers/openlayers.github.io/master/en/v5.3.0/build/ol.js\"></script>
    <title>OpenLayers example</title>
  </head>
  <body>
    <h2 style=\"text-align:center\">Localisation</h2>
    <div id=\"map\" class=\"map\"></div>
    <script type=\"text/javascript\">
      var map = new ol.Map({
        target: 'map',
        layers: [
          new ol.layer.Tile({
            source: new ol.source.OSM()
          })
        ],
        view: new ol.View({
          center: ol.proj.fromLonLat([-1.560117, 47.232283]),
          zoom: 19
        })
      });
    </script>
  </body>
47.232283, -1.560117


 <!--script>
      var map;
      function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 47.232283, lng: -1.560117},
          zoom: 19
        });
      }
    </script>
    <script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyB86pOzIw9R_NRKdqfOnjvc0-dVvCuQtn4&callback=initMap\"
    async defer></script-->
  </body>
</html>", "SFL2ApplicationBundle:Localisation:localisation.html.twig", "C:\\wamp64\\www\\site-sfl2\\src\\SFL2\\ApplicationBundle/Resources/views/Localisation/localisation.html.twig");
    }
}
