<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* SFL2ApplicationBundle:Emprunt:add.html.twig */
class __TwigTemplate_23ec0f6afbfc9ecfb7328d1128a41422e5d147bab9ffd5a69f4d28f93bb81a57 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "SFL2ApplicationBundle:Emprunt:add.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "SFL2ApplicationBundle:Emprunt:add.html.twig"));

        // line 1
        echo twig_include($this->env, $context, "base.html.twig");
        echo "

";
        // line 3
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    
    <div class=\"container-fluid\">

        <h1 style=\"text-align: center\">Ajouter un emprunt</h1>

        <div clas=\"well\">
            
            ";
        // line 11
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 11, $this->source); })()), 'form_start', ["attr" => ["class" => "form-horizontal"]]);
        echo "

            ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 13, $this->source); })()), 'errors');
        echo "
            
            <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fas fa-calendar-alt\"></i>
                    </div>
                </div>
                ";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 23, $this->source); })()), "debut", []), 'errors');
        echo "
            
                ";
        // line 25
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 25, $this->source); })()), "debut", []), 'widget', ["attr" => ["class" => "form-control "]]);
        echo "
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Début de l'emprunt</span>
        </div>
            
            <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fas fa-calendar-alt\"></i>
                    </div>
                </div>
                ";
        // line 38
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 38, $this->source); })()), "fin", []), 'errors');
        echo "
            
                ";
        // line 40
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 40, $this->source); })()), "fin", []), 'widget', ["attr" => ["class" => "form-control "]]);
        echo "
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Fin de l'emprunt</span>
        </div>
            
            <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fas fa-cube\"></i>
                    </div>
                </div>
                ";
        // line 53
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 53, $this->source); })()), "article", []), 'errors');
        echo "
            
                ";
        // line 55
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 55, $this->source); })()), "article", []), 'widget', ["attr" => ["class" => "form-control "]]);
        echo "
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Choisir l'article</span>
        </div>
            
            <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fas fa-user\"></i>
                    </div>
                </div>
                ";
        // line 68
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 68, $this->source); })()), "utilisateur", []), 'errors');
        echo "
            
                ";
        // line 70
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 70, $this->source); })()), "utilisateur", []), 'widget', ["attr" => ["class" => "form-control "]]);
        echo "
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Choisir l'emprunteur</span>
        </div>
            
           
            <div class=\"form-group\">
            ";
        // line 77
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 77, $this->source); })()), "ajouter", []), 'widget', ["attr" => ["class" => "btn btn-secondary"]]);
        echo "
            </div>
            
            
            
            ";
        // line 82
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 82, $this->source); })()), 'rest');
        echo "

            ";
        // line 84
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 84, $this->source); })()), 'form_end');
        echo "
        </div>
    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "SFL2ApplicationBundle:Emprunt:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  183 => 84,  178 => 82,  170 => 77,  160 => 70,  155 => 68,  139 => 55,  134 => 53,  118 => 40,  113 => 38,  97 => 25,  92 => 23,  79 => 13,  74 => 11,  65 => 4,  47 => 3,  42 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{include(\"base.html.twig\")}}

{% block  body %}
    
    <div class=\"container-fluid\">

        <h1 style=\"text-align: center\">Ajouter un emprunt</h1>

        <div clas=\"well\">
            
            {{ form_start(form, {'attr': {'class': 'form-horizontal'}}) }}

            {{ form_errors(form)}}
            
            <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fas fa-calendar-alt\"></i>
                    </div>
                </div>
                {{ form_errors(form.debut) }}
            
                {{ form_widget(form.debut, {'attr': {'class': 'form-control '}}) }}
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Début de l'emprunt</span>
        </div>
            
            <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fas fa-calendar-alt\"></i>
                    </div>
                </div>
                {{ form_errors(form.fin) }}
            
                {{ form_widget(form.fin, {'attr': {'class': 'form-control '}}) }}
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Fin de l'emprunt</span>
        </div>
            
            <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fas fa-cube\"></i>
                    </div>
                </div>
                {{ form_errors(form.article) }}
            
                {{ form_widget(form.article, {'attr': {'class': 'form-control '}}) }}
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Choisir l'article</span>
        </div>
            
            <div class=\"form-group\">
            <label></label> 
            <div class=\"input-group\">
                <div class=\"input-group-prepend\">
                    <div class=\"input-group-text\">
                        <i class=\"fas fa-user\"></i>
                    </div>
                </div>
                {{ form_errors(form.utilisateur) }}
            
                {{ form_widget(form.utilisateur, {'attr': {'class': 'form-control '}}) }}
            </div>                              
            <span id=\"HelpBlock\" class=\"form-text text-muted\">Choisir l'emprunteur</span>
        </div>
            
           
            <div class=\"form-group\">
            {{ form_widget(form.ajouter, {'attr': {'class': 'btn btn-secondary'}}) }}
            </div>
            
            
            
            {{ form_rest(form) }}

            {{ form_end(form) }}
        </div>
    </div>

{% endblock body %}
", "SFL2ApplicationBundle:Emprunt:add.html.twig", "C:\\wamp64\\www\\site-sfl2\\src\\SFL2\\ApplicationBundle/Resources/views/Emprunt/add.html.twig");
    }
}
