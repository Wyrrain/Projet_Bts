<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* SFL2ApplicationBundle:Utilisateur:index.html.twig */
class __TwigTemplate_8ab86053e6ab7a40c62486cf9c6fd8060131eccac79da86cb0be08d4970cfc63 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "SFL2ApplicationBundle:Utilisateur:index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "SFL2ApplicationBundle:Utilisateur:index.html.twig"));

        // line 2
        echo twig_include($this->env, $context, "base.html.twig");
        echo "

";
        // line 4
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "    <h1 style=\"text-align: center\">Gestion des Utilisateurs</h1>
  
    <a href=\"utilisateurs/add\" class=\"btn btn-secondary btn-md\" role=\"button\" aria-disabled=\"true\">Ajouter un utilisateur</a>
    <p></br></p>
    <table class=\"table table-striped\">
        <thead>
            <tr>

                <th scope=\"col\">Nom</th>
                <th scope=\"col\">Prénom</th>
                <th scope=\"col\">Fonction</th>
                <th scope=\"col\">Identifiant</th>
                <th scope=\"col\">Mot de passe</th>
                <th scope=\"col\">Commentaires</th>
                <th scope=\"col\">Modification</th>
            </tr>
        </thead>
        <tbody>

            ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["utilisateurs"]) || array_key_exists("utilisateurs", $context) ? $context["utilisateurs"] : (function () { throw new RuntimeError('Variable "utilisateurs" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 25
            echo "           
                <tr>

                    <td>";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "nom", []), "html", null, true);
            echo "</td>
                    <td>";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "prenom", []), "html", null, true);
            echo "</td>
                    <td>";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "fonction", []), "html", null, true);
            echo "</td>
                    <td>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "login", []), "html", null, true);
            echo "</td>
                    <td>";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "motdepasse", []), "html", null, true);
            echo "</td>
                    <td>";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "commentaires", []), "html", null, true);
            echo "</td>
  
                    <td><a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("sfl2_utilisateurs_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [])]), "html", null, true);
            echo "\" class=\"btn btn-secondary btn-sm\" role=\"button\" aria-disabled=\"true\">modifier</a>
                        <a href=\"\" class=\"btn btn-secondary btn-sm\" role=\"button\" aria-disabled=\"true\" data-toggle=\"modal\" data-target=\"#delete_";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "id", []), "html", null, true);
            echo "\">supprimer</a>
                       
                    </td>
                </tr>
                <div class=\"modal fade\" id=\"delete_";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "id", []), "html", null, true);
            echo "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"deleteLabel\" aria-hidden=\"true\">
                <div class=\"modal-dialog\" role=\"document\">
                  <div class=\"modal-content\">
                    <div class=\"modal-header\">
                      <h5 class=\"modal-title\" id=\"exampleModalLabel\">Supression</h5>
                      <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                        <span aria-hidden=\"true\">&times;</span>
                      </button>
                    </div>
                    <div class=\"modal-body\">
                      Voulez-vous vraiment supprimer ";
            // line 50
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "NomPrenom", []), "html", null, true);
            echo "?
                    </div>
                    <div class=\"modal-footer\">
                      <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Non</button>
                      <a href=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("sfl2_utilisateurs_del", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [])]), "html", null, true);
            echo "\" class=\"btn btn-secondary\" role=\"button\" aria-disabled=\"true\">Oui</a>
                    </div>
                  </div>
                </div>
              </div>
                
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "        </tbody>
        <tfoot>
            <tr>

                <th scope=\"col\">Nom</th>
                <th scope=\"col\">Prénom</th>
                <th scope=\"col\">Fonction</th>
                <th scope=\"col\">Identifiant</th>
                <th scope=\"col\">Mot de passe</th>
                <th scope=\"col\">Commentaires</th>
                <th scope=\"col\">Modification</th>
            </tr>
        </tfoot>
    </table>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "SFL2ApplicationBundle:Utilisateur:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 61,  151 => 54,  144 => 50,  131 => 40,  124 => 36,  120 => 35,  115 => 33,  111 => 32,  107 => 31,  103 => 30,  99 => 29,  95 => 28,  90 => 25,  86 => 24,  65 => 5,  47 => 4,  42 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# src/SFL2/ApplicationBundle/Resources/views/Utilisateur/utilisateur.html.twig #}
{{include(\"base.html.twig\")}}

{% block  body %}
    <h1 style=\"text-align: center\">Gestion des Utilisateurs</h1>
  
    <a href=\"utilisateurs/add\" class=\"btn btn-secondary btn-md\" role=\"button\" aria-disabled=\"true\">Ajouter un utilisateur</a>
    <p></br></p>
    <table class=\"table table-striped\">
        <thead>
            <tr>

                <th scope=\"col\">Nom</th>
                <th scope=\"col\">Prénom</th>
                <th scope=\"col\">Fonction</th>
                <th scope=\"col\">Identifiant</th>
                <th scope=\"col\">Mot de passe</th>
                <th scope=\"col\">Commentaires</th>
                <th scope=\"col\">Modification</th>
            </tr>
        </thead>
        <tbody>

            {% for user in utilisateurs %}
           
                <tr>

                    <td>{{user.nom}}</td>
                    <td>{{user.prenom}}</td>
                    <td>{{user.fonction}}</td>
                    <td>{{user.login}}</td>
                    <td>{{user.motdepasse}}</td>
                    <td>{{user.commentaires}}</td>
  
                    <td><a href=\"{{ path('sfl2_utilisateurs_edit', { 'id': user.id }) }}\" class=\"btn btn-secondary btn-sm\" role=\"button\" aria-disabled=\"true\">modifier</a>
                        <a href=\"\" class=\"btn btn-secondary btn-sm\" role=\"button\" aria-disabled=\"true\" data-toggle=\"modal\" data-target=\"#delete_{{user.id}}\">supprimer</a>
                       
                    </td>
                </tr>
                <div class=\"modal fade\" id=\"delete_{{user.id}}\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"deleteLabel\" aria-hidden=\"true\">
                <div class=\"modal-dialog\" role=\"document\">
                  <div class=\"modal-content\">
                    <div class=\"modal-header\">
                      <h5 class=\"modal-title\" id=\"exampleModalLabel\">Supression</h5>
                      <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                        <span aria-hidden=\"true\">&times;</span>
                      </button>
                    </div>
                    <div class=\"modal-body\">
                      Voulez-vous vraiment supprimer {{user.NomPrenom}}?
                    </div>
                    <div class=\"modal-footer\">
                      <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Non</button>
                      <a href=\"{{ path('sfl2_utilisateurs_del', {'id': user.id})}}\" class=\"btn btn-secondary\" role=\"button\" aria-disabled=\"true\">Oui</a>
                    </div>
                  </div>
                </div>
              </div>
                
            {% endfor %}
        </tbody>
        <tfoot>
            <tr>

                <th scope=\"col\">Nom</th>
                <th scope=\"col\">Prénom</th>
                <th scope=\"col\">Fonction</th>
                <th scope=\"col\">Identifiant</th>
                <th scope=\"col\">Mot de passe</th>
                <th scope=\"col\">Commentaires</th>
                <th scope=\"col\">Modification</th>
            </tr>
        </tfoot>
    </table>
{% endblock  body %}
", "SFL2ApplicationBundle:Utilisateur:index.html.twig", "C:\\wamp64\\www\\site-sfl2\\src\\SFL2\\ApplicationBundle/Resources/views/Utilisateur/index.html.twig");
    }
}
