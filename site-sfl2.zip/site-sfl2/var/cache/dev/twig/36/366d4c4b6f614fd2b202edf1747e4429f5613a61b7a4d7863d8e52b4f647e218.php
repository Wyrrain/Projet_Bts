<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_dc87ab73e816b5687b88439d0bbc7dca8ef63717131c17bcfc92de2c787aa7f0 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 9
        echo "        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"Responsive sidebar template with sliding effect and dropdown menu based on bootstrap 3\">
    
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\"
        crossorigin=\"anonymous\">
    <link href=\"https://use.fontawesome.com/releases/v5.0.6/css/all.css\" rel=\"stylesheet\">
    </head>
    <body>
       
        <div class=\"page-wrapper chiller-theme close-sidebar2\">
  <a id=\"show-sidebar\" class=\"btn btn-sm btn-dark\" href=\"#\">
    <i class=\"fas fa-bars\"></i>
  </a>
  <nav id=\"sidebar\" class=\"sidebar-wrapper\">
    <div class=\"sidebar-content\">
      <div class=\"sidebar-brand\">
        
        <a href=\"/site-sfl2/web/app_dev.php/accueil\"><i class=\"fas fa-home\"></i> Tracabilité RFID</a>
        <div id=\"close-sidebar\">
          <i class=\"fas fa-times\"></i>
        </div>
      </div>
      
      <div class=\"sidebar-menu\">
        <ul>
          <li class=\"header-menu\">
            <span>General</span>
          </li>
          <li class=\"sidebar-dropdown\">
            <a>
              <i class=\"fa fa-user\"></i>
              <span>Gestion des utilisateurs</span>
              
            </a>
            <div class=\"sidebar-submenu\">
              <ul>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/utilisateurs\">Utilisateurs
                    
                  </a>
                </li>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/utilisateurs/add\">Ajouter un utilisateur</a>
                </li>
              </ul>
            </div>
          </li>
          <li class=\"sidebar-dropdown\">
            <a>
              <i class=\"fa fa-suitcase\"></i>
              <span>Gestion des emprunts</span>
             
            </a>
            <div class=\"sidebar-submenu\">
              <ul>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/emprunts\">Emprunts

                  </a>
                </li>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/emprunts/add\">Ajouter un emprunt</a>
                </li>
              
              </ul>
            </div>
          </li>
        
          <li class=\"sidebar-dropdown\">
             <a href=\"/site-sfl2/web/app_dev.php/localisation\">
              <i class=\"fa fa-globe\"></i>
              <span>Localisation</span>
            </a>
            
          </li>
         
      </div>
   
    </div>
    
    <div class=\"sidebar-footer\">
      <a href=\"/site-sfl2/web/app_dev.php/login\">
        Déconnexion <i class=\"fas fa-sign-out-alt\"></i>
      </a>
    </div>
  </nav>
 
  
        ";
        // line 98
        $this->displayBlock('body', $context, $blocks);
        // line 99
        echo "        
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\" integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\"
        crossorigin=\"anonymous\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\"
        crossorigin=\"anonymous\"></script>
    <script src=\"";
        // line 105
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/base.js"), "html", null, true);
        echo "\"></script>
        ";
        // line 106
        $this->displayBlock('javascripts', $context, $blocks);
        // line 107
        echo "    </body>
 
    
    
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_title($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/base.css"), "html", null, true);
        echo "\"
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 98
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 106
    public function block_javascripts($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  236 => 106,  219 => 98,  206 => 7,  197 => 6,  179 => 5,  164 => 107,  162 => 106,  158 => 105,  150 => 99,  148 => 98,  57 => 9,  55 => 6,  51 => 5,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}
            <link rel=\"stylesheet\" href=\"{{ asset('css/base.css')}}\"
        {% endblock %}
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"Responsive sidebar template with sliding effect and dropdown menu based on bootstrap 3\">
    
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\"
        crossorigin=\"anonymous\">
    <link href=\"https://use.fontawesome.com/releases/v5.0.6/css/all.css\" rel=\"stylesheet\">
    </head>
    <body>
       
        <div class=\"page-wrapper chiller-theme close-sidebar2\">
  <a id=\"show-sidebar\" class=\"btn btn-sm btn-dark\" href=\"#\">
    <i class=\"fas fa-bars\"></i>
  </a>
  <nav id=\"sidebar\" class=\"sidebar-wrapper\">
    <div class=\"sidebar-content\">
      <div class=\"sidebar-brand\">
        
        <a href=\"/site-sfl2/web/app_dev.php/accueil\"><i class=\"fas fa-home\"></i> Tracabilité RFID</a>
        <div id=\"close-sidebar\">
          <i class=\"fas fa-times\"></i>
        </div>
      </div>
      
      <div class=\"sidebar-menu\">
        <ul>
          <li class=\"header-menu\">
            <span>General</span>
          </li>
          <li class=\"sidebar-dropdown\">
            <a>
              <i class=\"fa fa-user\"></i>
              <span>Gestion des utilisateurs</span>
              
            </a>
            <div class=\"sidebar-submenu\">
              <ul>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/utilisateurs\">Utilisateurs
                    
                  </a>
                </li>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/utilisateurs/add\">Ajouter un utilisateur</a>
                </li>
              </ul>
            </div>
          </li>
          <li class=\"sidebar-dropdown\">
            <a>
              <i class=\"fa fa-suitcase\"></i>
              <span>Gestion des emprunts</span>
             
            </a>
            <div class=\"sidebar-submenu\">
              <ul>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/emprunts\">Emprunts

                  </a>
                </li>
                <li>
                  <a href=\"/site-sfl2/web/app_dev.php/emprunts/add\">Ajouter un emprunt</a>
                </li>
              
              </ul>
            </div>
          </li>
        
          <li class=\"sidebar-dropdown\">
             <a href=\"/site-sfl2/web/app_dev.php/localisation\">
              <i class=\"fa fa-globe\"></i>
              <span>Localisation</span>
            </a>
            
          </li>
         
      </div>
   
    </div>
    
    <div class=\"sidebar-footer\">
      <a href=\"/site-sfl2/web/app_dev.php/login\">
        Déconnexion <i class=\"fas fa-sign-out-alt\"></i>
      </a>
    </div>
  </nav>
 
  
        {% block body %}{% endblock body %}
        
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\" integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\"
        crossorigin=\"anonymous\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\"
        crossorigin=\"anonymous\"></script>
    <script src=\"{{ asset('js/base.js')}}\"></script>
        {% block javascripts %}{% endblock %}
    </body>
 
    
    
</html>
", "base.html.twig", "C:\\wamp64\\www\\site-sfl2\\app\\Resources\\views\\base.html.twig");
    }
}
